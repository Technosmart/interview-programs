package testJ;
import java.util.*;

public class Revusingrecursion {
	static String reverse(String s) {
		   if(s.length() == 0)
		     return "";
		   return s.charAt(s.length() - 1) + reverse(s.substring(0,s.length()-1));
		 }
	public static void main(String[] args) {
		String test= "Jitnedra Khatri",output; 
		output=reverse(test);
		System.out.println(output);
		// TODO Auto-generated method stub

	}

}
