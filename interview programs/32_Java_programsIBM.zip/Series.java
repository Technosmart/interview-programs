package testJ;

public class Series {

	public static void main(String[] args) {
		int m=6, n=3,i;
		for(i=1;i<=4;i++)
		{
		System.out.println(m);
		m=m*2+n;
		n=n+2;
		}
	}

}
