package testJ;

import java.util.Scanner;
public class UserInputToArray {
public static void main(String[] args) {
// TODO Auto-generated method stub
//variable take the number of element in array
int arraylength;
Scanner scan = new Scanner(System.in);
System.out.println("please enter the length of array");
arraylength = scan.nextInt();
//user defined array
String[] inputArray = new String[arraylength];
//taking input into the array from user 
for(int i=0; i<arraylength ;i++){
System.out.println("please enter the name of person at the current position -"+i);
//syntax to enter element in an array
inputArray[i] = scan.next();
}
for(int i=0; i<arraylength ;i++){
//Retrieving element items
System.out.println("validation of items stored inside array as per user input -- "+inputArray[i]);
}
//always close scanner object, its better to get rid of memory lck.
scan.close(); 
}
}
