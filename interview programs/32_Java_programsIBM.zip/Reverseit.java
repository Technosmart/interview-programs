package testJ;
import java.util.*;
import java.io.*;

/*public class Reverseit {

	public static void main(String[] args) throws IOException
	{
		String inputString="Hello world how are you";
		String[] words = inputString.split(" ");
        
        String reverseString = "";
         
        for (int i = 0; i < words.length; i++) 
        {
            String word = words[i];
             
            String reverseWord = "";
             
            for (int j = word.length()-1; j >= 0; j--) 
            {
                reverseWord = reverseWord + word.charAt(j);
            }
             
            reverseString = reverseString + reverseWord + " ";
        }
        System.out.println(reverseString);
        }

	

}*/

/*import java.util.Scanner;
class Reverseit {

public static void main(String[] args) {
Scanner scan = new Scanner(System.in);
System.out.println("Enter the String with spaces");
String s = scan.nextLine();
String arr[] = s.split(" ");

for(int i= arr.length-1;i>=0;i--) {

System.out.print(arr[i] + " ");
}
scan.close();
}
}*/
//Input Hello world.
//Output world Hello
//import java.io.*;
//import java.util.*;

public class Reverseit {
public static void main(String[] args) {
String input="";
System.out.println("Enter the input string");
try
{
BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
input = br.readLine();
char[] try1= input.toCharArray();
for (int i=try1.length-1;i>=0;i--)
System.out.print(try1[i]);
}
catch (IOException e) {
e.printStackTrace();
}
}}

