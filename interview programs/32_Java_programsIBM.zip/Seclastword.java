package testJ;

public class Seclastword {

	public static void main(String[] args) 
	{
		String testString = "Hello World";
		String[] parts = testString.split(" ");
		String lastWord = parts[parts.length - 1];
		String firstWord = parts[parts.length - 2];
		System.out.println(lastWord+" "+firstWord); // "sentence"
		//System.out.println();
	}

}
