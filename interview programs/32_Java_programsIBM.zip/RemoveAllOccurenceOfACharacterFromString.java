package testJ;

import java.util.Scanner;
public class RemoveAllOccurenceOfACharacterFromString {
public static void main(String[] args) {
// TODO Auto-generated method stub
Scanner scan = new Scanner(System.in);
String inputString ="";
String outputString = "";
char replaceCharacter = ' ';
System.out.println(" please input your string");
inputString = scan.nextLine();
System.out.println("please input your character to replcae from the last given input");
replaceCharacter = scan.next().charAt(0);
for (int i = 0; i < inputString.length(); i++){
if (inputString.charAt(i) != replaceCharacter){
outputString += inputString.charAt(i);
}
}
System.out.println("here is your input string and the output string after replacing your input character --"+inputString +"--"+outputString);
}
}
