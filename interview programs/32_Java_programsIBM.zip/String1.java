package testJ;

import java.util.Scanner;
import java.util.Set;

public class String1 {
public static void main(String[] args) {

String str="aaabbddaabbcc";
int count=1;
String finalString="";
for(int i=1;i<str.length()-1;i++)
{
if(str.charAt(i)==str.charAt(i+1))
{
++count;

}
else
{

finalString+=str.charAt(i)+count+",";
count=1;
} 

}
System.out.println(finalString);
}
}
