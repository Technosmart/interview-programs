package testJ;

import java.util.Scanner;
public class printnext{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
String inputString="";
String outputString="";
System.out.print("Enter your string:");
inputString=sc.nextLine();
for(int i=0;i<inputString.length();i++){
char individualcharacter=inputString.charAt(i);
int local=(int) individualcharacter+1;
individualcharacter=(char)local;
outputString=outputString+individualcharacter;
}
System.out.print("the final sting is:"+outputString);
sc.close();
}

}
