package testJ;

public class Hello {

	public static void main(String[] args) {
		System.out.println("abc");
		String cde = "cde";
		System.out.println("abc" + cde);
		String c = "abc".substring(2,3);
		System.out.println(c);
		String d = cde.substring(1, 2);
		System.out.println(d);

	}

}
