package testJ;

import java.util.Scanner;
public class AsciiValue {
public static void main(String[] args) {
// TODO Auto-generated method stub
String inputString = "";

Scanner scan = new Scanner(System.in);
System.out.println("please enter your string");
inputString = scan.nextLine();
for(int i =0; i < inputString.length(); i++)
{
System.out.println(" we are going to print the decimal ascii value character by character --"+(int)inputString.charAt(i));
}
scan.close();

}
}
