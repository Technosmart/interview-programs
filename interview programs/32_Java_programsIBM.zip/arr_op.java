package testJ;

public class arr_op {

	public static void main(String[] args) {
		int i;
		int arr_va[]= new int[10];
		/*for(i=0; i<10;++i)
		//{
			arr_va[i]=i;
			System.out.println(arr_va[i]+ " ");
			i++;
		//}*/
		
		System.out.println(arr_va);

	}

}
