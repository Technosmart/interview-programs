package testJ;

public class Cointchar {

	public static void main(String[] args) {
		String s = "abc$sf$fdf df$vdjd4 dfhh4$$";
		int counter = 0;
		for( int i=0; i<s.length(); i++ ) {
		    if( s.charAt(i) == '$' ) {
		        counter++;
		    } 
		}
		System.out.println(counter);

	}

}
