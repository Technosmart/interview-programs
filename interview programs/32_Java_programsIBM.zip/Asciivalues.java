package testJ;

public class Asciivalues {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String testi = "abcde";
		String testi1 = "ABCDE";
	    char[] ascii1 = testi.toCharArray();
	    char[] ascii12 = testi1.toCharArray();

	    for(char ch:ascii1){
	       // System.out.println((int)ch+"  ");
	        System.out.print((int)ch+" ");
	       
	    }
	    System.out.println(" ");
	    for(char ch1:ascii12){
		       // System.out.println((int)ch+"  ");
		        
		        System.out.print((int)ch1+" ");
		    }
	    char character = testi.charAt(0);
	    int single1 = (int) character;
	    System.out.println("\n"+single1);
	    for(char alphabet = 'A'; alphabet <= 'Z';alphabet++) {
	        System.out.println(alphabet);
	    }
	    for(int i=65;i<=90;i++) {
	        System.out.println((char)i);
	    } 

	}

}
