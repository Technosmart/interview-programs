package testJ;

public class Casechange {

	public static void main(String[] args) {
		String str = "Hello World";
		String cap = str.substring(0, 1).toLowerCase() +str.substring(1,6).toUpperCase()+str.substring(6, 7).toLowerCase()+ str.substring(7).toUpperCase();
		System.out.println(cap);

	}

}
