package testJ;
import java.io.*;
import java.util.*;

public class Removevowels 
{

	public static void main(String[] args) 
	{
		String strOrig, strNew, strnew1;
	       Scanner scan = new Scanner(System.in);
	       
	       System.out.print("Enter a String : ");
	       strOrig = scan.nextLine();
	       
	       System.out.print("Removing Vowels from The String [" +strOrig+ "]\n");
	      strNew = strOrig.replaceAll("[aeiouAEIOU]", "");
	       strnew1 = strOrig.replaceAll("\\s+"," ");
		   
	       System.out.print("All Vowels Removed Successfully..!!\nNow the String is :\n");
	              
	       System.out.println(strNew);
	       System.out.println(strnew1);

	}

}
