package testJ;
import java.util.*;
public class Main 
{
public static void main(String[] arg)
{
System.out.println("Enter any string with spaces");
String s1=new String();
Scanner scn=new Scanner(System.in);
s1=scn.nextLine();
String st=s1.replaceAll("^ +| +$|( )+", "$1");
/* ^_+ is for any sequence of spaces at the beginning of the string
* _+$ is for any sequence of spaces at the end of the string
* (_)+ is for any sequence of spaces that matches none 
* of the above, meaning it's in the middle......., 
* all sequence of space will replace with $1(means single space)	
*/
System.out.println(st);
}
}