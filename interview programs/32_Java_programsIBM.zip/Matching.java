package testJ;

public class Matching {

	public static void main(String[] args) {
		 String s1 = "Sure Nag Rao";
		 
	     System.out.println(s1.startsWith("Sure"));        // true	
	     System.out.println(s1.startsWith("Nag", 5));      // true
	     System.out.println(s1.endsWith("Rao"));           // true
	 
	     System.out.println(s1.startsWith("God"));         // false
	     System.out.println(s1.endsWith("Almighty"));      // false
	 
	                    // one live demo of separating all the names of the students ending with Rao
	 
	     String students[] = { "Sure Nag Rao",  "Sridhar",  "Jyostna", "Srinivas Rao" };
	     System.out.println("\nFollowing are the students that ends with Rao");
	 
	     for(int i = 0; i < students.length; i++)
	     {
	        if(students[i].endsWith("Rao"))
	        {
	            System.out.println(students[i]);
	        }
	      }

	}

}
