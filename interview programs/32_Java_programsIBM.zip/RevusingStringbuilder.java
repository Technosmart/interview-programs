package testJ;

public class RevusingStringbuilder {

	public static void main(String[] args) {
		String str= "hello world";
		StringBuilder sb = new StringBuilder(str); 
		str = sb.reverse().toString();
		System.out.println(str);

	}

}
