package testJ;
import java.util.*;

class Codechef
{
public static void main (String[] args) 
{
int n;
Scanner sc = new Scanner(System.in);
System.out.println("enter the value of an integer");
n = sc.nextInt();
System.out.println("entered the value of integer is:-"+n);
sc.close();
}
}
