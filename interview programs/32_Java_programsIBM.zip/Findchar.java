package testJ;

public class Findchar {

	public static void main(String[] args) {
		 String str = "pqrpqrpqr";
		 
		    System.out.println(str.indexOf('r'));       // prints 2
		    System.out.println(str.indexOf("qrp"));   	// prints 1
		    System.out.println(str.indexOf('u'));       // prints -1
		 
		    System.out.println(str.lastIndexOf('p')); 	// prints 6
		         
		    System.out.println(str.charAt(3));          // prints p
		    
		    System.out.println(str.length());           // 9, total characters 
		    System.out.println(str.charAt(12));	        // throws StringIndexOutOfBoundsException
		    
	
	}

}
