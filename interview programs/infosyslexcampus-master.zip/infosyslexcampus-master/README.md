# infosyslexcampus
Solutions to the Most of the Infosys Lex Campus Connect Assignments and Exercises

This GIT is solely for Educational and training Purpose only.

Try to find the soltions on your own for better understandability of given problem

All The Best.

Note: I am not responsible for anything that happens in your life.. 
